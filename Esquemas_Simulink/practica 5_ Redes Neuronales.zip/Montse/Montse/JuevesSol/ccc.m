function ccc(src,evnt)
evnt
src
    y=get(gcf,'CurrentCharacter')
end