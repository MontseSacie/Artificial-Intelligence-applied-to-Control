function [efector,angulo] = preparaDatos(efector,angulo)
%PREPARADATOS Summary of this function goes here
%   Detailed explanation goes here
    d = size(efector);
    ultimaFila = efector(d, :);
    %efector(d ,:) = [];
    i = 1;
    %matriz = zeros(d(1) - 1,6);
    matriz = zeros(d(1) - 1, 6);
    while i < d(1)
    %matriz(i,:) = [efector(i,:), ultimaFila];
    matriz(i, 1) = efector(i, 1);
    matriz(i, 2) = efector(i, 2);
    matriz(i, 3) = efector(i, 3);
    matriz(i, 4) = ultimaFila(1, 1);
    matriz(i, 5) = ultimaFila(1, 2);
    matriz(i, 6) = ultimaFila(1, 3);
    i = i +1;
    end
    entrada = matriz';
    salida_base = angulo(:, 1)';
    salida_hombro = angulo(:, 2)';
    salida_codo = angulo(:, 3)';
    salida_mv = angulo(:, 4)';
    save entrada
    save salida_base;
    save salida_hombro;
    save salida_codo;
    save salida_mv;
end

 

